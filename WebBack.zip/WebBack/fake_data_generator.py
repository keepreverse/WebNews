import random
import os
from datetime import datetime, timedelta
from faker import Faker
from werkzeug.security import check_password_hash
from database.db import Storage

fake = Faker("ru_RU")

class MockFileWrapper:
    """Обёртка для эмуляции объекта файла Flask"""
    def __init__(self, file_path):
        self.file_path = file_path
        self.filename = os.path.basename(file_path)
        self.file = open(file_path, 'rb')
        
    def close(self):
        self.file.close()

class TestDataGenerator:
    def __init__(self):
        self.db = Storage()
        self.db.open_connection()
        self.cleanup_actions = []
        self.generated_data = {
            'users': [],
            'news': [],
            'categories': []
        }

    def __del__(self):
        self.cleanup()
        self.db.close_connection()

    def cleanup(self):
        """Очистка тестовых данных"""
        for action in reversed(self.cleanup_actions):
            try:
                action()
            except Exception as e:
                print(f"Ошибка при очистке: {str(e)}")

    def generate_users(self, count=5):
        """Генерация пользователей с защитой от дубликатов"""
        roles = ["Administrator", "Moderator", "Publisher"]
        existing = set()
        
        # Получаем существующие логины и ники
        current_users = self.db.user_get_all()
        existing.update((u['login'].lower(), u['nick'].lower()) for u in current_users)

        for _ in range(count):
            attempts = 0
            while True:
                login = f"{fake.user_name()}{random.randint(1000,9999)}"
                nick = f"{fake.first_name()}{random.randint(1000,9999)}"
                if (login.lower(), nick.lower()) not in existing:
                    break
                attempts += 1
                if attempts > 100:
                    raise Exception("Не удается создать уникального пользователя")

            user_data = {
                "login": login,
                "password": fake.password(length=12),
                "nick": nick,
                "role": random.choice(roles)
            }

            try:
                user_id = self.db.user_create(
                    login=user_data["login"],
                    password=user_data["password"],
                    nickname=user_data["nick"],
                    role=user_data["role"]
                )
                
                user = self.db.user_get_by_login(user_data["login"])
                assert user is not None, "Пользователь не создан"
                assert check_password_hash(user[1], user_data["password"]), "Неверный хеш пароля"
                
                self.generated_data['users'].append(user_id)
                self.cleanup_actions.append(lambda: self.db.user_delete(user_id))
                
                print(f"Создан пользователь: {user_data['login']}")
                existing.add((login.lower(), nick.lower()))
                
            except Exception as e:
                print(f"Ошибка создания пользователя: {str(e)}")
                raise

    def generate_categories(self, count=5):
        """Генерация категорий с гарантией уникальности"""
        existing = set(c['name'].lower() for c in self.db.category_get_all())
        
        for _ in range(count):
            name = fake.unique.word().capitalize()
            while name.lower() in existing:
                name = fake.unique.word().capitalize()
                
            try:
                category_id = self.db.category_create(
                    name=name,
                    description=fake.sentence()
                )
                
                categories = self.db.category_get_all()
                assert any(c['categoryID'] == category_id for c in categories), "Категория не найдена"
                
                self.generated_data['categories'].append(category_id)
                self.cleanup_actions.append(lambda: self.db.category_delete(category_id))
                
                print(f"Создана категория: {name}")
                existing.add(name.lower())
                
            except Exception as e:
                print(f"Ошибка создания категории: {str(e)}")
                raise

    def generate_news(self, count=20):
        """Генерация новостей с валидацией"""
        if not self.generated_data['users']:
            raise Exception("Требуются пользователи для создания новостей")

        statuses = ["Pending", "Approved", "Rejected", "Archived"]
        
        for i in range(count):
            try:
                event_start = fake.date_time_between("-30d", "+30d")
                event_end = event_start + timedelta(hours=random.randint(1, 72))
                
                news_data = {
                    "title": fake.sentence(nb_words=6),
                    "description": fake.text(max_nb_chars=500),
                    "status": random.choice(statuses),
                    "event_start": event_start.strftime("%Y-%m-%d %H:%M:%S"),
                    "event_end": event_end.strftime("%Y-%m-%d %H:%M:%S"),
                    "categoryID": random.choice(self.generated_data['categories']) if self.generated_data['categories'] else None
                }

                user_id = random.choice(self.generated_data['users'])

                self.db.news_add(
                    user_id=user_id,
                    news_input_data=news_data,
                    files_received=False,
                    files_list=[],
                    files_folder=os.path.abspath("uploads")
                )

                news_list = self.db.news_getlist()
                assert any(n['title'] == news_data['title'] for n in news_list), "Новость не найдена"
                
                created_news = next(n for n in news_list if n['title'] == news_data['title'])
                assert created_news['event_start'] == news_data['event_start'], "Ошибка в event_start"
                assert created_news['event_end'] == news_data['event_end'], "Ошибка в event_end"
                
                print(f"Создана новость: {news_data['title']}")
                
            except Exception as e:
                print(f"Ошибка создания новости: {str(e)}")
                raise

    def test_soft_delete(self):
        """Тестирование мягкого удаления"""
        try:
            news_ids = [n['newsID'] for n in self.db.news_getlist()]
            if not news_ids:
                raise Exception("Нет новостей для тестирования")

            test_id = random.choice(news_ids)
            self.db.news_soft_delete(test_id)
            
            deleted_news = self.db.get_deleted_news()
            assert any(n['newsID'] == test_id for n in deleted_news), "Новость не в корзине"
            
            self.db.restore_news([test_id])
            assert not any(n['newsID'] == test_id for n in self.db.get_deleted_news()), "Ошибка восстановления"
            
            print("Тест мягкого удаления пройден")
            
        except Exception as e:
            print(f"Ошибка теста мягкого удаления: {str(e)}")
            raise

    def test_purge(self):
        """Тестирование окончательного удаления"""
        test_path = None
        try:
            test_file = f"test_purge_{datetime.now().strftime('%Y%m%d%H%M%S')}.txt"
            test_path = os.path.abspath(os.path.join("uploads", test_file))
            
            with open(test_path, 'w') as f:
                f.write("test content")

            file_wrapper = MockFileWrapper(test_path)
            
            news_id = self.db.news_add(
                user_id=random.choice(self.generated_data['users']),
                news_input_data={
                    "title": "TEST NEWS FOR PURGE",
                    "description": "TEST CONTENT",
                    "status": "Approved"
                },
                files_received=True,
                files_list=[file_wrapper],
                files_folder=os.path.abspath("uploads")
            )
            file_wrapper.close()

            self.db.news_soft_delete(news_id)
            self.db.purge_news([news_id])
            
            assert not os.path.exists(test_path), "Файл не удален"
            assert not any(n['newsID'] == news_id for n in self.db.get_deleted_news()), "Новость не удалена"
            
            print("Тест очистки пройден")
            
        except Exception as e:
            print(f"Ошибка теста очистки: {str(e)}")
            raise
        finally:
            if test_path and os.path.exists(test_path):
                try:
                    os.remove(test_path)
                except Exception as e:
                    print(f"Ошибка удаления тестового файла: {str(e)}")

if __name__ == "__main__":
    tester = None
    try:
        tester = TestDataGenerator()
        
        print("\n=== Тест создания пользователей ===")
        tester.generate_users(5)
        
        print("\n=== Тест создания категорий ===")
        tester.generate_categories(3)
        
        print("\n=== Тест создания новостей ===")
        try:
            tester.generate_news(11)
        except Exception as e:
            print(f"Внимание: создано только {len(tester.generated_data['news'])} новостей")
            raise
        
        print("\n=== Тест работы с корзиной ===")
        tester.test_soft_delete()
        tester.test_purge()
        
        print("\nВсе тесты успешно пройдены!")
        
    except Exception as e:
        print(f"\n!!! Тест провален: {str(e)}")
        if tester:
            tester.cleanup()
        exit(1)