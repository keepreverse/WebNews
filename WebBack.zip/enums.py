from enum import Enum


class InvalidValues(Enum):
    INVALID_ID = -1
