import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import { api } from "../../services/apiClient";
import { getAuthToken, isTokenValid } from "../../services/authHelpers";
import PageWrapper from "../../components/PageWrapper";
import "./LoginPage.css";

const LoginPage = () => {
  const navigate = useNavigate();
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);

  useEffect(() => {
    const token = getAuthToken();
    if (token && isTokenValid(token)) {
      api.setAuthToken(token);
      navigate("/news-creator");
    }
  }, [navigate]);

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      if (!login.trim() || !password.trim()) {
        throw new Error("Логин и пароль обязательны");
      }

      const response = await api.post("/auth/login", {
        login: login.trim(),
        password: password.trim(),
      });

      if (!response.token) {
        throw new Error("Сервер не вернул токен");
      }

      // Сохраняем user
      const userData = {
        id: response.userID,
        login: response.login,
        role: response.user_role,
        nickname: response.nickname,
        token: response.token
      };

      const storage = rememberMe ? localStorage : sessionStorage;
      storage.setItem("user", JSON.stringify(userData));
      api.setAuthToken(response.token);

      toast.success("Успешный вход");
      navigate("/news-creator");
    } catch (err) {
      console.error("Ошибка авторизации:", err);
      toast.error(err.message || "Ошибка входа");
    }
  };

  return (
    <PageWrapper>
      <Helmet>
        <title>Авторизация</title>
      </Helmet>
      <div id="auth-form" className="container">
        <h1>Авторизация</h1>
        <div className="content">
          <form onSubmit={handleLogin}>
            <input
              type="text"
              name="login"
              className="inpt"
              placeholder="Введите логин"
              value={login}
              onChange={(e) => setLogin(e.target.value)}
              required
            />
            <input
              type="password"
              name="password"
              className="inpt"
              placeholder="Введите пароль"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <div className="checkbox-container">
              <input
                type="checkbox"
                id="remember"
                className="checkbox-input"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
              />
              <label htmlFor="remember" className="checkbox-label">
                Оставаться в системе
              </label>
            </div>
            <button type="submit" className="custom_button">
              Войти
            </button>
          </form>
          <ToastContainer position="top-right" autoClose={3000} />
        </div>
      </div>
    </PageWrapper>
  );
};

export default LoginPage;
