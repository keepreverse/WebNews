import React from 'react';

export class ErrorBoundary extends React.Component {
  state = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error("Error Boundary caught:", error, errorInfo);
    
    // Только для Jodit ошибок
    if (error.message.includes('Jodit')) {
      this.setState({ hasError: true });
      
      // Пытаемся мягко восстановиться без перезагрузки
      setTimeout(() => {
        try {
          const editors = document.querySelectorAll('.jodit-container');
          editors.forEach(editor => {
            if (editor.parentNode) {
              editor.parentNode.removeChild(editor);
            }
          });
          this.setState({ hasError: false });
        } catch (cleanupError) {
          console.error("Cleanup failed:", cleanupError);
          window.location.reload();
        }
      }, 100);
    }
  }

  render() {
    return this.state.hasError ? (
      <div className="error-fallback">
        Редактор перезагружается...
      </div>
    ) : this.props.children;
  }
}